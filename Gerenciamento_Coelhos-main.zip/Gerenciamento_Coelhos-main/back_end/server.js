// server.js

// 1. Importar as bibliotecas necessárias
const express = require('express');
const { Pool } = require('pg'); // Driver do PostgreSQL
const cors = require('cors');

// 2. Configurar o aplicativo Express
const app = express();
const port = 3000; // A porta onde o servidor irá rodar

// 3. Configurar os Middlewares
app.use(cors()); // Permite requisições de outras origens (do seu HTML)
app.use(express.json()); // Permite que o servidor entenda JSON no corpo das requisições

// 4. Configurar a Conexão com o Banco de Dados
// Substitua com as suas credenciais do PostgreSQL
const pool = new Pool({
  user: 'seu_usuario_do_banco',      // Ex: 'postgres'
  host: 'localhost',
  database: 'seu_banco_de_dados',
  password: 'sua_senha_do_banco',
  port: 5432, // Porta padrão do PostgreSQL
});

// 5. Definir a Rota para Adicionar um Coelho (o "Endpoint")
// O caminho '/coelho' deve ser o mesmo do atributo 'action' do seu formulário HTML
app.post('/coelho', async (req, res) => {
  console.log('Recebida requisição para adicionar coelho:', req.body);

  // Extrai os dados do corpo da requisição (enviados pelo formulário)
  const {
    numero_coelho,
    nome_coelho,
    raca_coelho,
    data_nascimento_coelho,
    sexo_coelho,
    observacoes_coelho,
    peso_nascimento,
    peso_atual,
    tipo_coelho,
    data_desmame,
    matriz_coelho,      // Este campo e o próximo precisam de um tratamento especial
    reprodutor_coelho,  //
    id_usuario          // Assume-se que este virá do formulário
  } = req.body;

  // --- Lógica de Cruzamento (Importante!) ---
  // A tabela 'cruzamento' liga um coelho à sua mãe e pai.
  // Antes de inserir na tabela 'coelho', você precisa dos IDs da mãe e do pai.
  // Aqui, estamos assumindo que 'matriz_coelho' e 'reprodutor_coelho' são os NÚMEROS dos coelhos.
  // Você precisará buscar os IDs deles primeiro.

  try {
    // Inicia uma transação para garantir a integridade dos dados
    await pool.query('BEGIN');

    // Monta o comando SQL para inserir na tabela 'coelho'
    // Usar placeholders ($1, $2, ...) previne SQL Injection
    const insertCoelhoQuery = `
      INSERT INTO coelho (
        numero_coelho, nome_coelho, raca_coelho, data_nascimento_coelho,
        sexo_coelho, observacoes_coelho, peso_nascimento, peso_atual,
        tipo_coelho, data_desmame, id_usuario
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
      RETURNING id_coelho; -- Retorna o ID do coelho que acabamos de criar
    `;

    const coelhoValues = [
      numero_coelho, nome_coelho, raca_coelho, data_nascimento_coelho,
      sexo_coelho, observacoes_coelho || null, peso_nascimento || null, peso_atual || null,
      tipo_coelho || null, data_desmame || null, id_usuario
    ];

    // Executa a inserção do coelho
    const resultCoelho = await pool.query(insertCoelhoQuery, coelhoValues);
    const newCoelhoId = resultCoelho.rows[0].id_coelho;

    // Se a matriz e o reprodutor foram informados, cria o registro de cruzamento
    if (matriz_coelho && reprodutor_coelho) {
      // Primeiro, encontre o 'id_coelho' da mãe e do pai usando seus números
      const getMaeIdQuery = 'SELECT id_coelho FROM coelho WHERE numero_coelho = $1';
      const maeResult = await pool.query(getMaeIdQuery, [matriz_coelho]);
      const maeId = maeResult.rows.length > 0 ? maeResult.rows[0].id_coelho : null;

      const getPaiIdQuery = 'SELECT id_coelho FROM coelho WHERE numero_coelho = $1';
      const paiResult = await pool.query(getPaiIdQuery, [reprodutor_coelho]);
      const paiId = paiResult.rows.length > 0 ? paiResult.rows[0].id_coelho : null;
      
      if (maeId && paiId) {
          const insertCruzamentoQuery = `
            INSERT INTO cruzamento (id_coelho, mae_coelho, pai_coelho)
            VALUES ($1, $2, $3);
          `;
          await pool.query(insertCruzamentoQuery, [newCoelhoId, maeId, paiId]);
      }
    }

    // Confirma a transação
    await pool.query('COMMIT');

    // Envia uma resposta de sucesso para o front-end
    res.status(201).json({ message: 'Coelho adicionado com sucesso!', id: newCoelhoId });

  } catch (error) {
    // Desfaz a transação em caso de erro
    await pool.query('ROLLBACK');
    console.error('Erro ao salvar no banco de dados:', error);
    res.status(500).json({ error: 'Erro interno do servidor ao salvar o coelho.' });
  }
});

// 6. Iniciar o Servidor
app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});
